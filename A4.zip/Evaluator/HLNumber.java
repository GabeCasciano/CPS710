public class HLNumber extends HLObject{

    public int intType(){
        return HLType.NUM;
    }

    public String toString(){
        return null;
    }

}
