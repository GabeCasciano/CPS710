#!/bin/bash

wget http://cps710.scs.ryerson.ca/F20/A4/Handouts/HL.jjt
wget http://cps710.scs.ryerson.ca/F20/A4/Handouts/IdentifierToken.java
wget http://cps710.scs.ryerson.ca/F20/A4/Handouts/NumberToken.java
wget http://cps710.scs.ryerson.ca/F20/A4/Handouts/SimpleNode.java
wget http://cps710.scs.ryerson.ca/F20/A4/Handouts/StringToken.java
wget http://cps710.scs.ryerson.ca/F20/A4/Handouts/TestHL.java
wget http://cps710.scs.ryerson.ca/F20/A4/Handouts/Token.java
wget http://cps710.scs.ryerson.ca/F20/A4/Handouts/makefile
wget http://cps710.scs.ryerson.ca/F20/A4/Handouts/options
wget http://cps710.scs.ryerson.ca/F20/A4/Handouts/t
wget http://cps710.scs.ryerson.ca/F20/A4/Handouts/HLDefaultVisitor.java
wget http://cps710.scs.ryerson.ca/F20/A4/Handouts/HLObject.java
wget http://cps710.scs.ryerson.ca/F20/A4/Handouts/HLType.java
