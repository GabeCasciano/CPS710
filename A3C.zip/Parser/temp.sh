#!/bin/bash

wget http://cps710.scs.ryerson.ca/F20/A3/Handouts/HL.jjt
wget http://cps710.scs.ryerson.ca/F20/A3/Handouts/IdentifierToken.java
wget http://cps710.scs.ryerson.ca/F20/A3/Handouts/NumberToken.java
wget http://cps710.scs.ryerson.ca/F20/A3/Handouts/SimpleNode.java
wget http://cps710.scs.ryerson.ca/F20/A3/Handouts/StringToken.java
wget http://cps710.scs.ryerson.ca/F20/A3/Handouts/TestHL.java
wget http://cps710.scs.ryerson.ca/F20/A3/Handouts/Token.java
wget http://cps710.scs.ryerson.ca/F20/A3/Handouts/makefile
wget http://cps710.scs.ryerson.ca/F20/A3/Handouts/options
wget http://cps710.scs.ryerson.ca/F20/A3/Handouts/runtestsa
wget http://cps710.scs.ryerson.ca/F20/A3/Handouts/runtestsb
wget http://cps710.scs.ryerson.ca/F20/A3/Handouts/runtestsc
wget http://cps710.scs.ryerson.ca/F20/A3/Handouts/ta
wget http://cps710.scs.ryerson.ca/F20/A3/Handouts/tb
wget http://cps710.scs.ryerson.ca/F20/A3/Handouts/tc
