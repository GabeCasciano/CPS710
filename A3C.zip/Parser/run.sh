#!/bin/bash

java -classpath .:./AST TestHL
